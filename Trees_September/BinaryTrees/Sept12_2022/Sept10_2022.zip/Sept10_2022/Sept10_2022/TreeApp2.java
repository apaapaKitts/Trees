package Sept10_2022;

/** This is an implementation of 'Tree2'. I have authored all of TreeApp2 as well as Tree2.
 *
 * September 6, 2022
 * Author: Andrew Pauls
 */
public class TreeApp2 {

    public Tree2 someTree = new Tree2();

    public TreeApp2 () {
        System.out.println("Testing our tree methods");


    }



    public static void main (String [] args) { TreeApp2 t2 = new TreeApp2();}
}
