Date: September 10, 2022
Author: Andrew Pauls


The binary search tree is now complete.

TreeApp2 File is still hectic and will be cleaned out later.
