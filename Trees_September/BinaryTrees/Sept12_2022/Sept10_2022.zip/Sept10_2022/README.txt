Date: September 10, 2022
Author: Andrew Pauls


Having spent the last 90 mins debugging the delete() method - specifically
attempting to solve issues with code for when the node to be deleted is 
the root case, I have failed to correctly identify where the issue is
in my code, and the program does not execute properly.

As a result, I will upload the program code ( even though it still contains
errors ) and reread the code that Mitchell Waite's textbook provides for 
BST. I know the code in Waite's textbook operates properly, and it is
significantly shorter and more efficient than the code I have produced
thus far. Nonetheless, my tree is very close to proper execution, and
it has been very worthwhile to attempt to build my own BST entirely from
scratch. 
