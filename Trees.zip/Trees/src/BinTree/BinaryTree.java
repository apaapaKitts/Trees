package BinTree;

public class BinaryTree {

    public TreeNode root;

    public BinaryTree() {
        root = null;
    }



    public void add ( int Value ) {
        if ( isEmpty() ) {
            root = new TreeNode(Value,new TreeNode(-1,null,null),new TreeNode(-1, null, null));
        }
        else {
            add(Value, root);
        }
    }

    private void add (int Value, TreeNode subTree) {
        // if the node is the right node!
        if ( subTree.val == -1 ) {subTree.val = Value; subTree.left = new TreeNode(-1,null,null);subTree.right=new TreeNode(-1, null, null);return;}



        if ( subTree.val > Value ) {       // value of subtree is greater than value to be inserted
            add(Value, subTree.left);
        }
        if ( subTree.val <= Value ) {
            add(Value, subTree.right);
        }
    }

    private void displayTree () {


    }

        //method chaining
    private void remove ( int value ) {
        this.remove(value, root);
    }
        //
    private void remove ( int value, TreeNode node ) {
        if (node.val == value) {        // if the node is the one to be deleted
            // check if it has children
            if ( (node.left.val & node.right.val) == -1) {      // if the node is the last meaningful node
                node.val = -1;
                node.left = null;
                node.right = null;
            }
            else if ( node.left.val != -1 ) {
                
            }
            }
    }

    public int getMax (TreeNode node) {
        int result = 0;
        while ( node.right.val != -1 ) {
            node = node.right;
        }
        result = node.val;
        return result;
    }

    public int getMin (TreeNode node) {
        int result = 0;
        while ( node.left.val != -1 ) {
            node = node.left;
        }
        result = node.val;
        return result;
    }

    public TreeNode getRoot() {
        return root;
    }

    public boolean isEmpty() {
        return root == null;
    }

    private int getSize() {
        return 0;
    }

}
