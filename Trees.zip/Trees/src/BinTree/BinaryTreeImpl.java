package BinTree;

public class BinaryTreeImpl {

    public BinaryTree someTree;

    public BinaryTreeImpl () {
        someTree = new BinaryTree();

//        System.out.println("Lets see if our tree is empty");
//        System.out.println("someTree is empty: " + someTree.isEmpty() );
//        System.out.println();
//
//
//        System.out.println("Now we will add an element to our binary tree");
        someTree.add(5);
//        System.out.println("Lets see if our tree is still empty. Is it empty? " + someTree.isEmpty());
//        System.out.println();
////
//        System.out.println("Lets check what the root value is: ");
//        System.out.println("The root value is: " + someTree.getRoot());
//        System.out.println("Now adding another value. We will add the value 2.");
        someTree.add(2);
        someTree.add(1);
        System.out.println("Left child: " + someTree.root.left.val);
        System.out.println("Left grandchild: " + someTree.root.left.left.val);
        someTree.add(9);
        someTree.add(8);
        System.out.println("right child: " + someTree.root.right.val);
        System.out.println("right grandchild: " + someTree.root.right.left.val);

        someTree.add(7);
        someTree.add(6);
        System.out.println("right child: " + someTree.root.right.left.left.val);
        System.out.println("right grandchild: " + someTree.root.right.left.left.left.val);

        someTree.add(5);
        System.out.println("right grandchild: " + someTree.root.right.left.left.left.left.val);


        someTree.add(-1);
        System.out.println("right grandchild: " + someTree.root.left.left.left.val);
        System.out.println("right grandchild: " + someTree.root.left.left.left.left.val);



        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("lets check if the min method works initially. MIN: " + someTree.getMin(someTree.getRoot()));
        someTree.add(0);
        System.out.println("lets check if the min method works initially. MIN: " + someTree.getMin(someTree.getRoot()));


        someTree.add(100);
        System.out.println("lets check if the max method works initially. MAX: " + someTree.getMax(someTree.getRoot()));
    }


    public static void main (String [] args) {BinaryTreeImpl b = new BinaryTreeImpl();}
}